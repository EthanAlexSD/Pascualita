import React, { useEffect, useState, useMemo, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import {
    ClipboardList, Package, AlertTriangle, TrendingUp, Plus, ArrowRight,
    CheckCircle2, Truck, Boxes, Car,
} from 'lucide-react';
import {
    BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid,
} from 'recharts';
import pb from '@/lib/pocketbaseClient';
import useRealtimeCollection from '@/hooks/useRealtimeCollection';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
    ESTADOS_PEDIDO, ESTADO_MAP, formatCurrency, formatWeight, formatDate, formatNumber,
} from '@/lib/pascualita';
import CountUp from '@/components/CountUp';
import Reveal from '@/components/Reveal';

const SUMMARY_STATES = ['creado', 'armado', 'en_ruta', 'entregado'];

export default function DashboardPage() {
    const { user, role } = useAuth();
    const [pedidos, setPedidos] = useState([]);
    const [productos, setProductos] = useState([]);
    const [camionetas, setCamionetas] = useState([]);
    const [loading, setLoading] = useState(true);

    const load = useCallback(async () => {
        try {
            const [peds, prods, trucks] = await Promise.all([
                pb.collection('pedidos').getFullList({ sort: '-created', expand: 'cliente,creado_por,camioneta' }),
                pb.collection('productos').getFullList({ sort: 'nombre' }),
                pb.collection('camionetas').getFullList({ sort: 'placa' }),
            ]);
            setPedidos(peds);
            setProductos(prods);
            setCamionetas(trucks);
        } catch (err) {
            console.error('dashboard load failed', err);
        }
        setLoading(false);
    }, []);

    useEffect(() => { load(); }, [load]);
    // Datos en vivo: el panel refleja al instante cambios de pedidos, stock y flota.
    useRealtimeCollection('pedidos', () => { load(); });
    useRealtimeCollection('productos', () => { load(); });
    useRealtimeCollection('camionetas', () => { load(); });

    const byState = useMemo(() => {
        const m = {};
        for (const e of ESTADOS_PEDIDO) m[e] = 0;
        for (const p of pedidos) if (p.estado in m) m[p.estado]++;
        return m;
    }, [pedidos]);

    const lowStock = useMemo(() => productos.filter((p) => p.stock_actual <= p.stock_minimo), [productos]);

    const chartData = useMemo(() => {
        const days = {};
        const now = new Date();
        for (let i = 6; i >= 0; i--) {
            const d = new Date(now);
            d.setDate(now.getDate() - i);
            const key = d.toISOString().slice(0, 10);
            days[key] = { label: d.toLocaleDateString('es-MX', { weekday: 'short' }), pedidos: 0, entregados: 0 };
        }
        for (const p of pedidos) {
            const key = (p.created || '').slice(0, 10);
            if (key in days) {
                days[key].pedidos++;
                if (p.estado === 'entregado') days[key].entregados++;
            }
        }
        return Object.values(days);
    }, [pedidos]);

    const recent = pedidos.slice(0, 6);
    const totalVentas = pedidos.filter((p) => p.estado === 'entregado').reduce((s, p) => s + Number(p.total || 0), 0);

    const cards = [
        { state: 'creado', label: 'Creados', icon: ClipboardList, color: '#64748b' },
        { state: 'armado', label: 'Armados', icon: Boxes, color: '#8b5cf6' },
        { state: 'en_ruta', label: 'En Ruta', icon: Truck, color: '#f97316' },
        { state: 'entregado', label: 'Entregados', icon: CheckCircle2, color: '#16a34a' },
    ];

    return (
        <div className="space-y-6">
            <Helmet>
                <title>Dashboard · Pascualita</title>
                <meta name="description" content="Panel principal del sistema Pascualita: pedidos por estado, inventario y rutas." />
            </Helmet>

            <Reveal>
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                        <h1 className="text-2xl font-bold">Panel de control</h1>
                        <p className="text-muted-foreground">Resumen operativo · {user?.name}</p>
                    </div>
                    <div className="flex gap-2">
                        {(role === 'dueno' || role === 'secretaria') && (
                            <Button asChild className="brand-gradient text-white">
                                <Link to="/pedidos/nuevo"><Plus className="h-4 w-4 mr-1" /> Nuevo pedido</Link>
                            </Button>
                        )}
                        <Button asChild variant="outline">
                            <Link to="/pedidos">Ver pedidos <ArrowRight className="h-4 w-4 ml-1" /></Link>
                        </Button>
                    </div>
                </div>
            </Reveal>

            {/* Summary cards */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {cards.map((c, i) => {
                    const Icon = c.icon;
                    return (
                        <Reveal key={c.state} delay={i * 0.05}>
                            <Card className="relative overflow-hidden">
                                <div className="absolute top-0 left-0 right-0 h-1" style={{ backgroundColor: c.color }} />
                                <CardContent className="pt-5">
                                    <div className="flex items-start justify-between">
                                        <div>
                                            <p className="text-sm text-muted-foreground">{c.label}</p>
                                            <p className="text-3xl font-bold mt-1">
                                                {loading ? '—' : <CountUp value={byState[c.state]} duration={900} />}
                                            </p>
                                        </div>
                                        <div className="h-10 w-10 rounded-lg flex items-center justify-center" style={{ backgroundColor: `${c.color}1a` }}>
                                            <Icon className="h-5 w-5" style={{ color: c.color }} />
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>
                        </Reveal>
                    );
                })}
            </div>

            {/* Quick stats row */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <Reveal>
                    <Card>
                        <CardContent className="pt-5 flex items-center gap-4">
                            <div className="h-11 w-11 rounded-lg bg-[hsl(var(--accent))]/15 flex items-center justify-center">
                                <TrendingUp className="h-5 w-5 text-[hsl(var(--accent))]" />
                            </div>
                            <div>
                                <p className="text-sm text-muted-foreground">Ventas entregadas</p>
                                <p className="text-xl font-bold">{formatCurrency(totalVentas)}</p>
                            </div>
                        </CardContent>
                    </Card>
                </Reveal>
                <Reveal delay={0.05}>
                    <Card>
                        <CardContent className="pt-5 flex items-center gap-4">
                            <div className="h-11 w-11 rounded-lg bg-primary/15 flex items-center justify-center">
                                <Package className="h-5 w-5 text-primary" />
                            </div>
                            <div>
                                <p className="text-sm text-muted-foreground">Productos en catálogo</p>
                                <p className="text-xl font-bold">{loading ? '—' : formatNumber(productos.length)}</p>
                            </div>
                        </CardContent>
                    </Card>
                </Reveal>
                <Reveal delay={0.1}>
                    <Card>
                        <CardContent className="pt-5 flex items-center gap-4">
                            <div className="h-11 w-11 rounded-lg bg-sky-500/15 flex items-center justify-center">
                                <Car className="h-5 w-5 text-sky-500" />
                            </div>
                            <div>
                                <p className="text-sm text-muted-foreground">Camionetas activas</p>
                                <p className="text-xl font-bold">{loading ? '—' : camionetas.filter((t) => t.activa).length} / {camionetas.length}</p>
                            </div>
                        </CardContent>
                    </Card>
                </Reveal>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Chart */}
                <Reveal className="lg:col-span-2">
                    <Card>
                        <CardHeader>
                            <CardTitle className="text-base">Pedidos de los últimos 7 días</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="h-64">
                                <ResponsiveContainer width="100%" height="100%">
                                    <BarChart data={chartData} barGap={6} barCategoryGap="22%">
                                        <defs>
                                            <linearGradient id="gPed" x1="0" y1="0" x2="0" y2="1">
                                                <stop offset="0%" stopColor="hsl(16 100% 60%)" />
                                                <stop offset="100%" stopColor="hsl(340 90% 56%)" stopOpacity={0.85} />
                                            </linearGradient>
                                            <linearGradient id="gEnt" x1="0" y1="0" x2="0" y2="1">
                                                <stop offset="0%" stopColor="hsl(158 84% 45%)" />
                                                <stop offset="100%" stopColor="hsl(190 90% 42%)" stopOpacity={0.85} />
                                            </linearGradient>
                                        </defs>
                                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                                        <XAxis dataKey="label" tickLine={false} axisLine={false} tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }} />
                                        <YAxis allowDecimals={false} tickLine={false} axisLine={false} tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }} />
                                        <Tooltip contentStyle={{ borderRadius: 8, border: '1px solid hsl(var(--border))', fontSize: 12 }} />
                                        <Bar dataKey="pedidos" fill="url(#gPed)" radius={[8, 8, 0, 0]} name="Pedidos" animationDuration={900} animationEasing="ease-out" />
                                        <Bar dataKey="entregados" fill="url(#gEnt)" radius={[8, 8, 0, 0]} name="Entregados" animationDuration={900} animationBegin={150} animationEasing="ease-out" />
                                    </BarChart>
                                </ResponsiveContainer>
                            </div>
                        </CardContent>
                    </Card>
                </Reveal>

                {/* Low stock alert */}
                <Reveal delay={0.05}>
                    <Card className="h-full">
                        <CardHeader>
                            <CardTitle className="text-base flex items-center gap-2">
                                <AlertTriangle className="h-4 w-4 text-destructive" /> Alertas de stock bajo
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-3">
                            {lowStock.length === 0 && (
                                <p className="text-sm text-muted-foreground py-6 text-center">Todo el inventario en niveles saludables ✓</p>
                            )}
                            {lowStock.slice(0, 6).map((p) => (
                                <div key={p.id} className="flex items-center justify-between gap-2 rounded-lg border border-border p-2.5">
                                    <div className="min-w-0">
                                        <p className="text-sm font-medium truncate">{p.nombre}</p>
                                        <p className="text-[11px] text-muted-foreground">{p.sku}</p>
                                    </div>
                                    <Badge variant="destructive" className="shrink-0">{p.stock_actual} / mín {p.stock_minimo}</Badge>
                                </div>
                            ))}
                            {lowStock.length > 6 && (
                                <Link to="/inventario" className="text-xs text-primary hover:underline block">+ {lowStock.length - 6} más…</Link>
                            )}
                            {lowStock.length > 0 && (
                                <Button asChild variant="outline" size="sm" className="w-full mt-2">
                                    <Link to="/inventario">Ir al inventario</Link>
                                </Button>
                            )}
                        </CardContent>
                    </Card>
                </Reveal>
            </div>

            {/* Recent orders */}
            <Reveal>
                <Card>
                    <CardHeader>
                        <CardTitle className="text-base">Pedidos recientes</CardTitle>
                    </CardHeader>
                    <CardContent className="p-0">
                        <div className="overflow-x-auto">
                            <table className="w-full text-sm">
                                <thead className="bg-muted/50 text-muted-foreground text-xs uppercase">
                                    <tr>
                                        <th className="text-left font-medium px-4 py-3">Folio</th>
                                        <th className="text-left font-medium px-4 py-3">Cliente</th>
                                        <th className="text-left font-medium px-4 py-3 hidden sm:table-cell">Estado</th>
                                        <th className="text-right font-medium px-4 py-3 hidden md:table-cell">Peso</th>
                                        <th className="text-right font-medium px-4 py-3">Total</th>
                                        <th className="text-left font-medium px-4 py-3 hidden lg:table-cell">Fecha</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {recent.map((p) => {
                                        const est = ESTADO_MAP[p.estado];
                                        const cliente = p.expand?.cliente;
                                        return (
                                            <tr key={p.id} className="border-t border-border hover:bg-muted/40">
                                                <td className="px-4 py-3">
                                                    <Link to={`/pedidos/${p.id}`} className="font-medium text-primary hover:underline">{p.folio}</Link>
                                                </td>
                                                <td className="px-4 py-3">{cliente?.nombre || '—'}</td>
                                                <td className="px-4 py-3 hidden sm:table-cell">
                                                    <span className="inline-flex items-center gap-1.5 text-xs font-medium">
                                                        <span className="h-2 w-2 rounded-full" style={{ backgroundColor: est?.color }} />
                                                        {est?.label}
                                                    </span>
                                                </td>
                                                <td className="px-4 py-3 text-right hidden md:table-cell text-muted-foreground">{formatWeight(p.peso_total)}</td>
                                                <td className="px-4 py-3 text-right font-medium">{formatCurrency(p.total)}</td>
                                                <td className="px-4 py-3 hidden lg:table-cell text-muted-foreground">{formatDate(p.created)}</td>
                                            </tr>
                                        );
                                    })}
                                    {recent.length === 0 && !loading && (
                                        <tr><td colSpan={6} className="px-4 py-8 text-center text-muted-foreground">Aún no hay pedidos.</td></tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </CardContent>
                </Card>
            </Reveal>
        </div>
    );
}
