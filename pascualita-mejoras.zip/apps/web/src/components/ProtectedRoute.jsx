import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';

const ProtectedRoute = ({ children, roles, redirectTo = '/login' }) => {
    const { isAuthed, role, loading } = useAuth();
    const location = useLocation();

    if (loading) {
        return (
            <div className="grid min-h-screen place-items-center">
                <div className="h-10 w-10 animate-spin rounded-full border-4 border-primary/20 border-t-primary" />
            </div>
        );
    }
    if (!isAuthed) return <Navigate to={redirectTo} replace state={{ from: location.pathname }} />;
    if (roles?.length && !roles.includes(role)) return <Navigate to="/dashboard" replace />;
    return children;
};

export default ProtectedRoute;
export { ProtectedRoute };
