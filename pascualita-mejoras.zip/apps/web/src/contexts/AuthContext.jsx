import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import pb from '@/lib/pocketbaseClient';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
    const [user, setUser] = useState(pb.authStore.record);
    const [loading, setLoading] = useState(pb.authStore.isValid);

    useEffect(() => {
        const unsub = pb.authStore.onChange((_t, record) => setUser(record));
        // Revalida token/usuario contra el servidor (detecta tokens vencidos, usuarios borrados o inactivos).
        if (pb.authStore.isValid) {
            pb.collection('users')
                .authRefresh()
                .then((r) => { if (r.record.activo === false) pb.authStore.clear(); })
                .catch(() => pb.authStore.clear())
                .finally(() => setLoading(false));
        }
        return () => unsub?.();
    }, []);

    const login = useCallback(async (email, password) => {
        const res = await pb.collection('users').authWithPassword(email, password);
        if (res.record.activo === false) {
            pb.authStore.clear();
            throw new Error('Tu usuario está desactivado. Contacta al dueño.');
        }
        return res;
    }, []);

    const value = useMemo(
        () => ({
            user,
            isAuthed: !!user && pb.authStore.isValid,
            role: user?.role || null,
            loading,
            login,
            logout: () => pb.authStore.clear(),
            hasRole: (...roles) => !!user && roles.includes(user.role),
        }),
        [user, loading, login],
    );

    return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => useContext(AuthContext);
export default AuthContext;
