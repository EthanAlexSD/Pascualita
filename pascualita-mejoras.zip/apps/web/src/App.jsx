import React, { lazy, Suspense } from 'react';
import { Navigate, Route, Routes, BrowserRouter as Router } from 'react-router-dom';
import ScrollToTop from './components/ScrollToTop';
import { AuthProvider } from './contexts/AuthContext';
import ProtectedRoute from './components/ProtectedRoute';
import AppLayout from './components/AppLayout';
import LoginPage from './pages/LoginPage';
import NotFoundPage from './pages/NotFoundPage';
import { Toaster } from '@/components/ui/sonner';

// Carga diferida: recharts y las pantallas pesadas ya no inflan el bundle inicial.
const DashboardPage = lazy(() => import('./pages/DashboardPage'));
const OrdersPage = lazy(() => import('./pages/OrdersPage'));
const OrderDetailPage = lazy(() => import('./pages/OrderDetailPage'));
const CreateOrderPage = lazy(() => import('./pages/CreateOrderPage'));
const InventoryPage = lazy(() => import('./pages/InventoryPage'));
const ClientsPage = lazy(() => import('./pages/ClientsPage'));
const TrucksPage = lazy(() => import('./pages/TrucksPage'));
const DriversPage = lazy(() => import('./pages/DriversPage'));

const ADMIN = ['dueno', 'secretaria'];
const ROUTES = [
    ['/dashboard', DashboardPage],
    ['/pedidos', OrdersPage],
    ['/pedidos/nuevo', CreateOrderPage, ADMIN],
    ['/pedidos/:id', OrderDetailPage],
    ['/inventario', InventoryPage],
    ['/clientes', ClientsPage],
    ['/camionetas', TrucksPage],
    ['/choferes', DriversPage, ADMIN],
];

const Fallback = () => (
    <div className="grid min-h-[50vh] place-items-center">
        <div className="h-10 w-10 animate-spin rounded-full border-4 border-primary/20 border-t-primary" />
    </div>
);

function App() {
    return (
        <AuthProvider>
            <Router>
                <ScrollToTop />
                <Toaster richColors position="top-right" />
                <Routes>
                    <Route path="/login" element={<LoginPage />} />
                    {ROUTES.map(([path, Page, roles]) => (
                        <Route
                            key={path}
                            path={path}
                            element={
                                <ProtectedRoute roles={roles}>
                                    <AppLayout>
                                        <Suspense fallback={<Fallback />}><Page /></Suspense>
                                    </AppLayout>
                                </ProtectedRoute>
                            }
                        />
                    ))}
                    <Route path="/" element={<Navigate to="/dashboard" replace />} />
                    <Route path="*" element={<NotFoundPage />} />
                </Routes>
            </Router>
        </AuthProvider>
    );
}

export default App;
