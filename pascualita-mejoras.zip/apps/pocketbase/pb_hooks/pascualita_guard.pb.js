/// <reference path="../pb_data/types.d.ts" />
// Validación SERVER-SIDE de la máquina de estados (antes solo se validaba en el cliente).
onRecordUpdateRequest((e) => {
  const NEXT = {
    creado: ["enviado_almacen", "cancelado"], enviado_almacen: ["armado", "cancelado"],
    armado: ["cargado", "cancelado"], cargado: ["verificado", "cancelado"],
    verificado: ["en_ruta", "cancelado"], en_ruta: ["entregado", "cancelado"],
    entregado: [], cancelado: [],
  };
  const WHO = {
    "creado->enviado_almacen": ["dueno", "secretaria"], "enviado_almacen->armado": ["dueno", "almacen"],
    "armado->cargado": ["dueno", "almacen"], "cargado->verificado": ["dueno", "secretaria"],
    "verificado->en_ruta": ["dueno", "secretaria"], "en_ruta->entregado": ["dueno", "chofer"],
  };
  if (e.hasSuperuserAuth()) return e.next();
  let from = "";
  try { from = $app.findRecordById("pedidos", e.record.id).get("estado") || ""; } catch (_) { return e.next(); }
  const to = e.record.get("estado") || "";
  if (from !== to) {
    const role = (e.auth && e.auth.get("role")) || "";
    if (e.auth && e.auth.get("activo") === false) throw new ForbiddenError("Usuario inactivo.");
    if (!(NEXT[from] || []).includes(to)) throw new BadRequestError("Transición no permitida: " + from + " → " + to);
    const allowed = to === "cancelado" ? ["dueno"] : WHO[from + "->" + to] || [];
    if (!allowed.includes(role)) throw new ForbiddenError("Tu rol no puede pasar el pedido a '" + to + "'.");
  }
  e.next();
}, "pedidos");
