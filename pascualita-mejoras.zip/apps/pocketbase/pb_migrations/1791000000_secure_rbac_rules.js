/// <reference path="../pb_data/types.d.ts" />
// Endurece reglas de acceso: antes TODO usuario autenticado (chofer incluido) podía
// editar/borrar cualquier colección y cambiarse el rol. Ahora se aplica RBAC por rol.
migrate((app) => {
  const A = "@request.auth.id != ''";
  const is = (...r) => "(" + r.map((x) => `@request.auth.role = '${x}'`).join(" || ") + ")";
  const rules = {
    users: {
      updateRule: `(@request.auth.id = id && @request.body.role:isset = false && @request.body.disponible:isset = false && @request.body.activo:isset = false) || ${is("dueno")}`,
      deleteRule: `${is("dueno")} && @request.auth.id != id`,
    },
    clientes: { createRule: is("dueno", "secretaria"), updateRule: is("dueno", "secretaria"), deleteRule: is("dueno") },
    productos: { createRule: is("dueno", "almacen"), updateRule: is("dueno", "almacen"), deleteRule: is("dueno") },
    camionetas: {
      createRule: is("dueno"), deleteRule: is("dueno"),
      updateRule: `${is("dueno")} || (${is("secretaria", "almacen")} && @request.body.disponible:isset = false)`,
    },
    cargas: { createRule: is("dueno", "secretaria", "almacen"), updateRule: is("dueno", "secretaria", "almacen"), deleteRule: is("dueno") },
    carga_pedidos: { createRule: is("dueno", "secretaria", "almacen"), updateRule: is("dueno", "secretaria", "almacen"), deleteRule: is("dueno", "secretaria") },
    pedidos: { createRule: is("dueno", "secretaria"), updateRule: is("dueno", "secretaria", "almacen", "chofer"), deleteRule: is("dueno") },
    pedido_detalle: { createRule: is("dueno", "secretaria"), updateRule: is("dueno", "secretaria"), deleteRule: is("dueno", "secretaria") },
    notificaciones: {
      listRule: `${A} && (usuario = @request.auth.id || (usuario = '' && (rol_destino = @request.auth.role || rol_destino = 'todos')))`,
      viewRule: `${A} && (usuario = @request.auth.id || (usuario = '' && (rol_destino = @request.auth.role || rol_destino = 'todos')))`,
      updateRule: `${A} && @request.body.mensaje:isset = false && (usuario = @request.auth.id || rol_destino = @request.auth.role || rol_destino = 'todos')`,
      deleteRule: is("dueno"),
    },
    bitacora: {
      listRule: is("dueno", "contadora"), viewRule: is("dueno", "contadora"),
      createRule: `${A} && (@request.body.usuario:isset = false || @request.body.usuario = @request.auth.id)`,
    },
  };
  for (const name of Object.keys(rules)) {
    const col = app.findCollectionByNameOrId(name);
    Object.assign(col, rules[name]);
    app.save(col);
  }
}, () => {});
